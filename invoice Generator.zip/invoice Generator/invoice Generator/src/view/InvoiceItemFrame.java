/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Amira Bahaa
 */
package view;

import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JTextField;


public class InvoiceItemFrame extends JDialog{
    private JTextField txtBoxitemName;
    private JTextField txtBOxItemCount;
    private JTextField txtBoxItemPrice;
    private JLabel itemName_label;
    private JLabel itemCount_label;
    private JLabel itemPrice_label;
    private JButton add_btn;
    private JButton cancel_btn;
    
    public InvoiceItemFrame(Mainframe frame) {
        
        //item names
        txtBoxitemName = new JTextField(20);
        itemName_label = new JLabel("Item Name");
        
        ///item count
        txtBOxItemCount = new JTextField(20);
        itemCount_label = new JLabel("Item Count");
        
        //buttons
           
        add_btn = new JButton("Add");
        cancel_btn = new JButton("Cancel");
        
        
        //price  
        
        txtBoxItemPrice = new JTextField(20);
        itemPrice_label = new JLabel("Item Price");
     
        
        //actions
        add_btn.setActionCommand("addNewItem");
        cancel_btn.setActionCommand("cancelNewItem");
        
        add_btn.addActionListener(frame.getActionListener());
        cancel_btn.addActionListener(frame.getActionListener());
        setLayout(new GridLayout(4, 2));
        
        //func add
        add(itemName_label);
        add(txtBoxitemName);
        add(itemPrice_label);
        add(txtBoxItemPrice);
        add(itemCount_label);
        add(txtBOxItemCount);
        add(add_btn);
        add(cancel_btn);
        
        pack();
    }
  public JTextField getTxtBOxItemCount() {
        return txtBOxItemCount;
    }

    public JTextField getTxtBoxitemName() {
        return txtBoxitemName;
    }

  
    public JTextField getTxtBoxItemPrice() {
        return txtBoxItemPrice;
    }

    
}
