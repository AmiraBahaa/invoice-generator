/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Amira Bahaa
 */
package view;

import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class InvoiceHeaderFrame extends JDialog {
    private JTextField addNEwInvoiceCustNAme;
    private JTextField invDate_addNewInvoice_txtbox;
    private JLabel customerName;
    private JLabel invoiceDate;
    private JButton addButton;
    private JButton cancel_button;

    public InvoiceHeaderFrame(Mainframe frame) {
    
        cancel_button = new JButton("Cancel");
        invoiceDate = new JLabel("Invoice Date:");
        customerName = new JLabel("Customer Name:");
        addNEwInvoiceCustNAme = new JTextField(20);
      
        invDate_addNewInvoice_txtbox = new JTextField(20);
        addButton = new JButton("Add");
        addButton.setActionCommand("addNewInvoice_OK");
        cancel_button.setActionCommand("addNewInvoice_Cancel");
        
        addButton.addActionListener(frame.getActionListener());
        cancel_button.addActionListener(frame.getActionListener());
        setLayout(new GridLayout(3, 2));
        
        add(invoiceDate);
        add(invDate_addNewInvoice_txtbox);
        add(customerName);
        add(addNEwInvoiceCustNAme);
        add(addButton);
        add(cancel_button);
        
        pack();
        
    }

  

    public JTextField getInvDate_addNewInvoice_txtbox() {
        return invDate_addNewInvoice_txtbox;
    }
  public JTextField getAddNEwInvoiceCustNAme() {
        return addNEwInvoiceCustNAme;
    }
   
    
}
