/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Amira Bahaa
 */
package model;

import view.Mainframe;
import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;


public class InvoiceHeaderTableModel extends AbstractTableModel{
    private ArrayList<InvoiceHeader> invoicesHeaderArray;
    private String []columns = {"Invoice No.", "Date", "Customer Name", "Invoice Total"};

    public InvoiceHeaderTableModel(ArrayList<InvoiceHeader> invoicesHeaderArray) {
        this.invoicesHeaderArray = invoicesHeaderArray;
    }

    
    @Override
    public int getRowCount() {
        return invoicesHeaderArray.size();
    }

    @Override
    public int getColumnCount() {
        return columns.length;

    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        InvoiceHeader invoice = invoicesHeaderArray.get(rowIndex);
        switch(columnIndex)
        {
            case 0:
                return invoice.getNum();
            case 1:
                return Mainframe.df.format(invoice.getInvoiceDate());
            case 2:
                return invoice.getCustomerName();
            case 3:
                return invoice.getInvoiceTotal();
        }
        
        return "";
    }
    
    @Override
    public String getColumnName(int column)
    {
        return columns[column];
    }
    
}
