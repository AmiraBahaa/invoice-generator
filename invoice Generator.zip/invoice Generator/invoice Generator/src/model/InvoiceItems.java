/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Amira Bahaa
 */
package model;

public class InvoiceItems {
    private String item;
    private double priceItem;
    private int itemCount;
    private InvoiceHeader header;

    public InvoiceItems(String item, double itemPrice, int itemCount, InvoiceHeader header) {
        this.item = item;
        this.priceItem = itemPrice;
        this.itemCount = itemCount;
        this.header = header;
    }

    public String getItem() {
        return item;
    }

    public void setItem(String item) {
        this.item = item;
    }

    public double getPriceItem() {
        return priceItem;
    }

    public void setPriceItem(double priceItem) {
        this.priceItem = priceItem;
    }
   public InvoiceHeader getHeader() {
        return header;
    }

    public void setHeader(InvoiceHeader header) {
        this.header = header;
    }
    
    public double getItemTotal() {
        return priceItem * itemCount;
    }

    public int getItemCount() {
        return itemCount;
    }

    public void setItemCount(int itemCount) {
        this.itemCount = itemCount;
    }

 
    @Override
    public String toString() {
        return header.getNum() + ", " + item + ", " + priceItem + "  ," + itemCount;
    }
}
