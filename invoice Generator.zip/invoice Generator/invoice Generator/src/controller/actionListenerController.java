/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Amira Bahaa
 */
package controller;

import model.InvoiceHeader;
import model.InvoiceHeaderTableModel;
import model.InvoiceItems;
import model.ItemsTableModel;
import view.InvoiceHeaderFrame;
import view.InvoiceItemFrame;
import view.Mainframe;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;


public class actionListenerController implements ActionListener{
        private InvoiceItemFrame item;
    private Mainframe frame;
    private InvoiceHeaderFrame frameHeader;

            
    public actionListenerController(Mainframe frame)
    {
        this.frame = frame;
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        switch (e.getActionCommand()) {
           

            case "Load Invoice":
        {
            try {
                loadInvoice();
            } catch (ParseException ex) {
                JOptionPane.showMessageDialog(null, "Error", "Error in loading files", JOptionPane.ERROR_MESSAGE);
            }
        }
                break;
             case "addNewInvoice_OK":
                addNewInvoiceOK();
                break;
            case "Create New Invoice":
                createNewInvoice();
                break;

            case "Delete Invoice":
                deleteInvoice();
                break;
             case "Save Invoice":
                saveFiles();
                break;
            case "Add New Item":
                createNewItem();
                break;
                
            case "Delete Item":
                deleteItem();
                break;
                
           
                
            case "addNewInvoice_Cancel":
                addNewInvoiceCancel();
                break;
                
            case "newItem_add":
                addNewItemSave();
                break;
                
                
                
            case "newItem_cancel":
                addNewItemCancel();
                break;
                
        }
        
    }

    private void saveFiles() {
        ArrayList<InvoiceHeader> invoiceArr = frame.getInvoicesHeaderArray();
        JFileChooser fileChoosen = new JFileChooser("invoices\\");
        
        try
        {
            JOptionPane.showMessageDialog(frame, " Select the place you want to save the header file", "Header File", JOptionPane.INFORMATION_MESSAGE);
            int result = fileChoosen.showSaveDialog(frame);
            if(result == JFileChooser.APPROVE_OPTION)
            {
                File headerFile = fileChoosen.getSelectedFile();
                FileWriter fw = new FileWriter(headerFile);
                String header = "";
                String items = "";
                for(InvoiceHeader invoice: invoiceArr) 
                {
                    header += invoice.toString();
                    header += "\n";
                    for(InvoiceItems item: invoice.getItems())
                    {
                        items += item.toString();
                        items += "\n";
                    }
                }
                
                header = header.substring(0, header.length()-1);
                items = items.substring(0, items.length()-1);
                
                JOptionPane.showMessageDialog(frame, "Select the place you want to save the items file", "Items File", JOptionPane.INFORMATION_MESSAGE);
                result = fileChoosen.showSaveDialog(frame);
                File itemFile = fileChoosen.getSelectedFile();
                FileWriter fw1 = new FileWriter(itemFile);
                
                fw.write(header);
                fw1.write(items);
                fw.close();
                fw1.close();
                
                JOptionPane.showMessageDialog(frame, "Files saved successfully!!", "Saved Successfully", JOptionPane.INFORMATION_MESSAGE);

            }
        }
        catch(IOException e)
        {
            JOptionPane.showMessageDialog(frame, "Error in saving the file!..", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void loadInvoice() throws ParseException {
        JOptionPane.showMessageDialog(frame, "choose the header file", "Header File", JOptionPane.INFORMATION_MESSAGE);
        JFileChooser fc = new JFileChooser("invoices\\");
        try
        {
        
            int result = fc.showOpenDialog(frame);
            if(result == JFileChooser.APPROVE_OPTION)
            {
                // Reading header CSV file
                File headerInvoice = fc.getSelectedFile();
                Path headerPath = Paths.get(headerInvoice.getAbsolutePath());
                List<String> headerContents = Files.readAllLines(headerPath);
                ArrayList<InvoiceHeader> invoiceHeaders = new ArrayList<>();
                for(String headerContent: headerContents)
                {
                  String header[] = headerContent.split(",");
                  //String num_str = header[0];
                  //String date_str = header[1];
                  String name_str = header[2];
                  int invoiceNum = Integer.parseInt(header[0]);
                  Date invoiceDate = Mainframe.df.parse(header[1]);
                  InvoiceHeader newHeader = new InvoiceHeader(invoiceNum, name_str,invoiceDate);
                  invoiceHeaders.add(newHeader);

                }
            frame.setInvoicesHeaderArray(invoiceHeaders);
            
            
            //  Reading invoice items as csv and choose item file
            JOptionPane.showMessageDialog(frame, "choose the items file", "Items File", JOptionPane.INFORMATION_MESSAGE);
            result = fc.showOpenDialog(frame);
            if(result == JFileChooser.APPROVE_OPTION)
            {
                File itemsFile = fc.getSelectedFile();
                Path itemsFilePath = Paths.get(itemsFile.getAbsolutePath());
                List<String> itemsLines = Files.readAllLines(itemsFilePath);
                ArrayList<InvoiceItems> invoiceItems = new ArrayList<>();
                
                for (String lineLine : itemsLines) 
                {
                    String[] arr = lineLine.split(",");
                    String str1 = arr[0];   
                    String str2 = arr[1];   
                    String str3 = arr[2];    
                    String str4 = arr[3];    
                    int invoiceNum = Integer.parseInt(str1);
                    double itemPrice = Double.parseDouble(str3);
                    int itemCount = Integer.parseInt(str4);
                    InvoiceHeader header = frame.getInvoiceByNum(invoiceNum);
                    InvoiceItems line = new InvoiceItems(str2, itemPrice, itemCount, header);
                    header.getItems().add(line);
                }
                
            }
         
            InvoiceHeaderTableModel headerTableModel = new InvoiceHeaderTableModel(invoiceHeaders);
            frame.setHeaderTableModel(headerTableModel);
            frame.getTable2().setModel(headerTableModel);
            
            
            }
            
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(null, "Error", "Error in reading header file!..", JOptionPane.ERROR_MESSAGE);
            }
        
        System.out.println("Files read successfully!!");
    }   

  
    private void deleteInvoice() {
        int selectedInvoice = frame.getTable2().getSelectedRow();
        if(selectedInvoice != 1)
        {
            frame.getInvoicesHeaderArray().remove(selectedInvoice);
            frame.getHeaderTableModel().fireTableDataChanged();
            frame.getTable1().setModel(new ItemsTableModel(null));
            frame.setItemsArray(null);
            frame.getCustomerName_textbox().setText("");
            frame.getInvoiceNo_label().setText("");
            frame.getInvoiceTotal_label().setText("");
            frame.getInvoiceDate_textbox().setText("");
        }
    }
    
       private void deleteItem() {
    
        int selectedItem = frame.getTable1().getSelectedRow();
        
        if(selectedItem != -1)
        {
            frame.getItemsArray().remove(selectedItem);
            //Updating the tables
            ItemsTableModel itemModel =(ItemsTableModel) frame.getTable1().getModel();
            itemModel.fireTableDataChanged();
            frame.getHeaderTableModel().fireTableDataChanged();
        }
        
        
    }
       
       
    private void createNewItem() {
        item = new InvoiceItemFrame(frame);
        item.setVisible(true);
    }
  private void createNewInvoice() {
        frameHeader = new InvoiceHeaderFrame(frame);
        frameHeader.setVisible(true);
    }


 
    private void addNewItemSave() {
        item.setVisible(false);
    
        String nameOfItem = item.getTxtBoxitemName().getText();
        String countItem = item.getTxtBOxItemCount().getText();
        String priceItem = item.getTxtBoxItemPrice().getText();
        int itemCount = 1;
        double itemPrice = 1;
        
        try
        {
            itemCount = Integer.parseInt(countItem);
        }catch(Exception e)
        {
            //numbers 
            JOptionPane.showMessageDialog(frame, "Cannot convert numbers", "Invalid number formate", JOptionPane.ERROR_MESSAGE);
        }
        
        try
        {
            itemPrice = Double.parseDouble(priceItem);
        }catch(Exception e)
        {
            //price error
            JOptionPane.showMessageDialog(frame, "Can't convert price", "Invalid price formate", JOptionPane.ERROR_MESSAGE);
        }
      
        int headerSelect = frame.getTable2().getSelectedRow();
        if(headerSelect != -1)
        {
            InvoiceHeader header =  frame.getInvoicesHeaderArray().get(headerSelect);
            InvoiceItems newItem = new InvoiceItems(nameOfItem, itemPrice, itemCount, header);
    
            frame.getItemsArray().add(newItem);
           
            ItemsTableModel itemModel =(ItemsTableModel) frame.getTable1().getModel();
            itemModel.fireTableDataChanged();
            frame.getHeaderTableModel().fireTableDataChanged();

        }
        
        item.dispose();
        item = null;
    }


    private void addNewInvoiceOK() {
        frameHeader.setVisible(false);
        
        String custName = frameHeader.getAddNEwInvoiceCustNAme().getText();
        String date_str = frameHeader.getInvDate_addNewInvoice_txtbox().getText();
        
        // case If date is entered wrongly, set today's date
        
        Date date = new Date();
        try {
            date = Mainframe.df.parse(date_str);
        } catch (ParseException ex) {
            JOptionPane.showMessageDialog(null, "Date is entered incorrectly! . Setting to today's date","Error",  JOptionPane.ERROR_MESSAGE);
        }
        
        
        int invNumber = 0;
        for(InvoiceHeader invHead : frame.getInvoicesHeaderArray())
        {
            if(invHead.getNum() > invNumber)
            {
                invNumber = invHead.getNum();
            }
        }
        invNumber++;
        
        InvoiceHeader inv = new InvoiceHeader(0, custName, date);
        frame.getInvoicesHeaderArray().add(inv);
        frame.getHeaderTableModel().fireTableDataChanged();
        
        frameHeader.dispose();
        frameHeader = null;
    }

    private void addNewInvoiceCancel() {
        frameHeader.setVisible(false);
        frameHeader.dispose();
        frameHeader = null;
    }

    
    private void addNewItemCancel() {
        item.setVisible(false);
        item.dispose();
        item = null;
    }
    
    
    
   
    
}
