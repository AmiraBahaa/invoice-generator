/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Amira Bahaa
 */
package controller;

import model.InvoiceHeader;
import model.InvoiceItems;
import model.ItemsTableModel;
import view.Mainframe;
import java.util.ArrayList;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;


public class SelectionController implements ListSelectionListener{

    private Mainframe frame;

    public SelectionController(Mainframe frame) {
        this.frame = frame;
    }
    
    
    @Override
    public void valueChanged(ListSelectionEvent e) {
        int selectedInvIndex = frame.getTable2().getSelectedRow();
        System.out.println("Invoice Selected: " + selectedInvIndex);
        if(selectedInvIndex != -1)
        {
        InvoiceHeader selectedInvoiceHeader = frame.getInvoicesHeaderArray().get(selectedInvIndex);
        
    
        ArrayList<InvoiceItems> items = selectedInvoiceHeader.getItems();
        ItemsTableModel itemsTableModel = new ItemsTableModel(items);
        frame.setItemsArray(items);
        frame.getTable1().setModel(itemsTableModel);
        
        //Getting details of the invoice  and assigning it to frame objects
        
        frame.getCustomerName_textbox().setText(selectedInvoiceHeader.getCustomerName());
        frame.getInvoiceNo_label().setText(String.valueOf(selectedInvoiceHeader.getNum()));
        frame.getInvoiceTotal_label().setText(String.valueOf(selectedInvoiceHeader.getInvoiceTotal()));
        frame.getInvoiceDate_textbox().setText(Mainframe.df.format(selectedInvoiceHeader.getInvoiceDate()));
        }
    }
    
}
